
# Novedades:
# - imagen
# - titulo
# - descripcion
# - organizadores
# - fecha
# - articulo1
# - imagen1
# - articulo2
# - imagen2