

# eventos:
# 
# - imagen
# - titulo
# - descripcion
# - organizadores
# - fecha
# - descripcion_larga
# - imagenes-videos
# - url-ir_a_nuruk


